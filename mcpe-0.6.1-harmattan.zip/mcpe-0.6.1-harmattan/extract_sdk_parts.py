#!/usr/bin/env python3
"""Carve Nokia Qt SDK 1.2.1's three needed 7z components from its .run file.

This reads the .run as data; it does not execute the SDK installer.
Usage: python3 extract_sdk_parts.py [path/to/QtSdk-offline-linux-x86_64-v1.2.1.run] [output-directory]
"""
from pathlib import Path
import sys

DEFAULT_RUN = "QtSdk-offline-linux-x86_64-v1.2.1.run"
DEFAULT_OUT = "parts"
COMPONENTS = [
    ("arm-toolchain.7z", 444783839, 88239521),
    ("harmattan-sysroot.7z", 123227924, 196488385),
    ("qt-tools.7z", 117864531, 5363315),
]
MAGIC = b"7z\xbc\xaf\x27\x1c"
CHUNK = 1024 * 1024
EXPECTED_RUN_SIZE = 804478453


def main() -> int:
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(DEFAULT_RUN)
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(DEFAULT_OUT)
    if len(sys.argv) > 3:
        print(__doc__)
        return 2
    if not source.is_file():
        print(f"Файл не найден: {source}")
        print("Помести скрипт рядом с .run или передай путь к нему аргументом.")
        return 2
    total = source.stat().st_size
    if total != EXPECTED_RUN_SIZE:
        raise SystemExit(
            f"Неверный или неполный .run: {total:,} байт; "
            f"для Nokia Qt SDK 1.2.1 ожидается {EXPECTED_RUN_SIZE:,} байт. "
            "Проверь ZIP и распакуй его заново."
        )
    output.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as src:
        for name, offset, length in COMPONENTS:
            if offset + length > total:
                raise SystemExit(f"Файл .run слишком короткий для {name}: {total} байт")
            src.seek(offset)
            if src.read(len(MAGIC)) != MAGIC:
                raise SystemExit(f"Сигнатура не совпала для {name}; проверь, что это Nokia Qt SDK 1.2.1")
            src.seek(offset)
            dest = output / name
            remaining = length
            with dest.open("wb") as out:
                while remaining:
                    block = src.read(min(CHUNK, remaining))
                    if not block:
                        raise SystemExit(f"Неожиданный конец файла при записи {name}")
                    out.write(block)
                    remaining -= len(block)
            print(f"Готово: {dest} ({length:,} bytes)")
    print("Теперь распакуй полученные архивы командами из шага 3 инструкции.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
