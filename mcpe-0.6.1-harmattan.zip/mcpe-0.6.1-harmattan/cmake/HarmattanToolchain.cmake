# Nokia Qt SDK 1.2.1 / MeeGo 1.2 Harmattan toolchain.
# The SDK installer is not required: point HARMATTAN_SDK_ROOT at its manually
# extracted Qt SDK root (the directory containing toolchain/ and sysroot/).
# Defaults to ../toolchain-packages/extracted_sdk relative to this repository.
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR armv7l)

if(NOT DEFINED HARMATTAN_SDK_ROOT)
  if(DEFINED ENV{HARMATTAN_SDK_ROOT})
    set(HARMATTAN_SDK_ROOT "$ENV{HARMATTAN_SDK_ROOT}")
  else()
    get_filename_component(HARMATTAN_SDK_ROOT
      "${CMAKE_CURRENT_LIST_DIR}/../../toolchain-packages/extracted_sdk" ABSOLUTE)
  endif()
endif()

set(HARMATTAN_TOOLCHAIN "${HARMATTAN_SDK_ROOT}/toolchain/arm-2009q3-67")
set(HARMATTAN_SYSROOT "${HARMATTAN_SDK_ROOT}/sysroot")
set(CMAKE_C_COMPILER "${HARMATTAN_TOOLCHAIN}/bin/arm-none-linux-gnueabi-gcc")
set(CMAKE_CXX_COMPILER "${HARMATTAN_TOOLCHAIN}/bin/arm-none-linux-gnueabi-g++")
set(CMAKE_SYSROOT "${HARMATTAN_SYSROOT}")
set(CMAKE_FIND_ROOT_PATH "${HARMATTAN_SYSROOT}")
set(CMAKE_C_FLAGS_INIT "--sysroot=${HARMATTAN_SYSROOT}")
# GCC 4.4.1 uses the transitional C++0x switch, not -std=c++11/14.
set(CMAKE_CXX_FLAGS_INIT "--sysroot=${HARMATTAN_SYSROOT} -std=gnu++0x")
set(CMAKE_CXX_FLAGS "--sysroot=${HARMATTAN_SYSROOT} -std=gnu++0x -Doverride=" CACHE STRING "Harmattan C++ flags" FORCE)
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
