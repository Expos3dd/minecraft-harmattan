#ifndef APPPLATFORM_HARMATTAN_H__
#define APPPLATFORM_HARMATTAN_H__

#include "AppPlatform.h"
#include <string>

// Nokia N9 / MeeGo 1.2 Harmattan implementation. Paths are resolved below
// the installed application data directory (/opt/minecraft-pe-061/data).
class AppPlatform_harmattan : public AppPlatform {
public:
    AppPlatform_harmattan();
    virtual int getScreenWidth();
    virtual int getScreenHeight();
    virtual float getPixelsPerMillimeter();
    virtual bool supportsTouchscreen();
    virtual BinaryBlob readAssetFile(const std::string& filename);
    virtual TextureData loadTexture(const std::string& filename, bool textureFolder);
    virtual std::string getDateString(int seconds);
    virtual bool isNetworkEnabled(bool onlyWifiAllowed);
};

#endif
