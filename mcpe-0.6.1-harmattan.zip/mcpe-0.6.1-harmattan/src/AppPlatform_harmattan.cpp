#include "AppPlatform_harmattan.h"
#include "platform/log.h"
#include "world/level/storage/FolderMethods.h"
#include <QImage>
#include <sstream>
#include <cstdio>

namespace {
const char* DATA_ROOT = "/opt/minecraft-pe-061/data/";
std::string assetPath(const std::string& name) {
    return std::string(DATA_ROOT) + name;
}
}

AppPlatform_harmattan::AppPlatform_harmattan() {}
int AppPlatform_harmattan::getScreenWidth() { return 854; }
int AppPlatform_harmattan::getScreenHeight() { return 480; }
float AppPlatform_harmattan::getPixelsPerMillimeter() { return 854.0f / 71.0f; }
bool AppPlatform_harmattan::supportsTouchscreen() { return true; }
bool AppPlatform_harmattan::isNetworkEnabled(bool) { return true; }

BinaryBlob AppPlatform_harmattan::readAssetFile(const std::string& filename) {
    const std::string path = assetPath(filename);
    FILE* fp = std::fopen(path.c_str(), "rb");
    if (!fp) return BinaryBlob();
    std::fseek(fp, 0, SEEK_END);
    const long length = std::ftell(fp);
    std::rewind(fp);
    if (length < 0) { std::fclose(fp); return BinaryBlob(); }
    unsigned char* bytes = new unsigned char[static_cast<size_t>(length)];
    const size_t read = std::fread(bytes, 1, static_cast<size_t>(length), fp);
    std::fclose(fp);
    if (read != static_cast<size_t>(length)) { delete[] bytes; return BinaryBlob(); }
    return BinaryBlob(bytes, static_cast<unsigned int>(length));
}

TextureData AppPlatform_harmattan::loadTexture(const std::string& filename, bool textureFolder) {
    TextureData out;
    const std::string path = textureFolder ? assetPath(std::string("images/") + filename) : filename;
    QImage image(QString::fromUtf8(path.c_str()));
    if (image.isNull()) { LOGE("Harmattan: missing texture %s\n", path.c_str()); return out; }
    image = image.convertToFormat(QImage::Format_ARGB32);
    out.w = image.width();
    out.h = image.height();
    out.numBytes = 4 * out.w * out.h;
    out.data = new unsigned char[out.numBytes];
    out.memoryHandledExternally = false;
    // QImage::Format_ARGB32 is BGRA in memory on the N9's little-endian ARM.
    for (int y = 0; y < out.h; ++y) {
        const unsigned char* src = image.scanLine(y);
        unsigned char* dst = out.data + y * out.w * 4;
        for (int x = 0; x < out.w; ++x) {
            dst[x * 4 + 0] = src[x * 4 + 2];
            dst[x * 4 + 1] = src[x * 4 + 1];
            dst[x * 4 + 2] = src[x * 4 + 0];
            dst[x * 4 + 3] = src[x * 4 + 3];
        }
    }
    return out;
}

std::string AppPlatform_harmattan::getDateString(int seconds) {
    std::ostringstream result;
    result << seconds << " s (UTC)";
    return result.str();
}
