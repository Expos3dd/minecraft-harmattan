# Куда положить игровые ресурсы / Where game assets go

Сюда распакуйте ресурсы из вашей копии
Minecraft чтобы получить структуру вида:

    data/
      images/      
      lang/
      font|fonts/
      sound/
      app/         
      ...

