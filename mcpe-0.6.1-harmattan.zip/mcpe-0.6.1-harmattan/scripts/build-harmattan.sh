#!/bin/sh
# Build the native Nokia N9 package from inside a MeeGo 1.2 Harmattan SDK.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
BUILD_DIR=${BUILD_DIR:-"$ROOT/out/harmattan-armel"}

SDK_ROOT=${HARMATTAN_SDK_ROOT:-"$ROOT/../toolchain-packages/extracted_sdk"}
[ -x "$SDK_ROOT/toolchain/arm-2009q3-67/bin/arm-none-linux-gnueabi-g++" ] || {
  echo "ERROR: Harmattan compiler missing under $SDK_ROOT" >&2; exit 2;
}
[ -d "$SDK_ROOT/sysroot/usr/include/qt4" ] || {
  echo "ERROR: Harmattan Qt headers missing under $SDK_ROOT/sysroot" >&2; exit 2;
}
command -v cmake >/dev/null 2>&1 || { echo "ERROR: cmake not found" >&2; exit 2; }

cmake -S "$ROOT" -B "$BUILD_DIR" \
  -DHARMATTAN_SDK_ROOT="$SDK_ROOT" \
  -DCMAKE_TOOLCHAIN_FILE="$ROOT/cmake/HarmattanToolchain.cmake" \
  -DPLATFORM=PLATFORM_HARMATTAN \
  -DCMAKE_BUILD_TYPE=Release \
  -DHARMATTAN_FUNCTION_TRACE="${HARMATTAN_FUNCTION_TRACE:-OFF}" \
  -DCMAKE_INSTALL_PREFIX=/ \
  -DCPACK_DEBIAN_PACKAGE_ARCHITECTURE=armel
cmake --build "$BUILD_DIR" -- -j"${JOBS:-2}"
cmake --build "$BUILD_DIR" --target package
printf '\nPackage output: %s\n' "$BUILD_DIR"
ls -lh "$BUILD_DIR"/*.deb
